
const fileInput = document.getElementById('fileInput');
const keyInput = document.getElementById('keyInput');
const encryptBtn = document.getElementById('encryptBtn');
const decryptBtn = document.getElementById('decryptBtn');
const downloadLink = document.getElementById('downloadLink');

function wordArrayToUint8Array(wordArray) {
  const len = wordArray.sigBytes;
  const u8_array = new Uint8Array(len);
  let offset = 0;
  for (let i = 0; i < wordArray.words.length; i++) {
    let word = wordArray.words[i];
    for (let j = 3; j >= 0; j--) {
      if (offset < len) {
        u8_array[offset++] = (word >> (8 * j)) & 0xff;
      }
    }
  }
  return u8_array;
}

function processFile(isEncrypt) {
  const file = fileInput.files[0];
  const key = keyInput.value.trim();

  if (!file) {
    alert('Vui lòng chọn file!');
    return;
  }
  if (!key) {
    alert('Vui lòng nhập mã khóa AES!');
    return;
  }

  const reader = new FileReader();

  reader.onload = (e) => {
    try {
      if (isEncrypt) {
        const wordArray = CryptoJS.lib.WordArray.create(e.target.result);
        const encrypted = CryptoJS.AES.encrypt(wordArray, key).toString();
        const blob = new Blob([encrypted], { type: 'text/plain' });
        createDownloadLink(blob, file.name + '.aes');
      } else {
        const encryptedStr = e.target.result;
        const decrypted = CryptoJS.AES.decrypt(encryptedStr, key);

        if (decrypted.sigBytes <= 0) {
          alert('Giải mã thất bại! Mã khóa hoặc file không đúng.');
          return;
        }

        const uint8Array = wordArrayToUint8Array(decrypted);
        const blob = new Blob([uint8Array], { type: 'application/octet-stream' });

        let originalName = file.name.endsWith('.aes')
          ? file.name.slice(0, -4)
          : file.name + '.dec';

        createDownloadLink(blob, originalName);
      }
    } catch (err) {
      alert('Lỗi xử lý: ' + err.message);
    }
  };

  if (isEncrypt) {
    reader.readAsArrayBuffer(file);
  } else {
    reader.readAsText(file);
  }
}

function createDownloadLink(blob, filename) {
  const url = URL.createObjectURL(blob);
  downloadLink.href = url;
  downloadLink.download = filename;
  downloadLink.style.display = 'inline-block';
  downloadLink.textContent = 'Tải file: ' + filename;
}

encryptBtn.addEventListener('click', () => processFile(true));
decryptBtn.addEventListener('click', () => processFile(false));
